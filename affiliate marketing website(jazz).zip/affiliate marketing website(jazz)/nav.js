$('.brand img').attr('src',"themes/images/jazz_l.jpeg")
$('.brand img').css('width','200px')
$('.brand img').css('heigth','90px')
